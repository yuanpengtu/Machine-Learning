package kmeansimg;

public class dataItem {
	public double r;
	public double g;
	public double b;
	public int group;
}

